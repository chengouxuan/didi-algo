timed_cluster_order 各地区/各时间段 的订单量数据
timed_cluster_traffic 各地区/各时间段 的交通数据, lv1/lv2/lv3/lv4 分别为拥堵级别为1/2/3/4的道路数量
timed_weather 各时间段的天气情况, temperature==>室外温度, pm25==>pm2.5, weather==>题目未说明
timed_weather_avg timed_weather可能出现多条天气记录, 此表对同一时间段的天气记录取平均值
poi.csv 各地区的poi记录
poi_summed.csv 对各地区poi统计总和
combined 订单量, 交通数据, 天气, poi汇总
